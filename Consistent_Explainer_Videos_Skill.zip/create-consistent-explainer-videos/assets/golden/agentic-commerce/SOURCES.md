# Source and scope
AI x Commerce — Justine Moore and Alex Rampell, Andreessen Horowitz, 12 August 2025.
https://a16z.com/ai-x-commerce/
The four foundations summarise the article's Better data, Unified APIs, Identity and memory, and Embedded capture. The supplied infographic renames them Trustworthy data, Connected transactions, Identity & memory, and Feedback in the journey. The video orders personal constraints before authorised checkout to follow a coherent illustrative purchase.
The shoe, price, inventory, reviews and interface are hypothetical teaching examples, not a real product listing or live retailer demonstration. The investment firm's strategic thesis is not proof that every retailer supports these capabilities. Authorisation and retailer support are explicit. The approved video typography, colours, dimensions, timing approach, silence and footer-free layout are preserved.
