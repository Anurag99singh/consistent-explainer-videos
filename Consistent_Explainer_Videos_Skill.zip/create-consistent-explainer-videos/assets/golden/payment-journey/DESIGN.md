# Visual identity
## Style Prompt
Portrait editorial motion explainer, building one continuous illustrative card-payment story. Warm paper against deep green ink, oversized display typography, yellow highlights and pale blue interface panels. Crisp native app mockups, a cursor and moving request markers make the mechanism visible. The provided shoe illustration anchors the checkout opener. Leads are centred; the uppercase title header stays visually distinct. No footer labels.
## Colors
- #F4F1E8 paper
- #183535 ink
- #F3D55B yellow emphasis
- #DCEEF0 screenshot context
- #CBE6D8 saved-state confirmation
## Typography
FilmSans, embedded Nimbus Sans regular/bold. FilmSerif, embedded P052 Roman.
## Motion
Six scenes, 60 seconds. 0.5 second crossfades; staggered entrances; cursor moves to exact illustrated controls. Keep labels visible long enough to read. Parent scenes start hidden. Progress bar is persistent. Reading holds are intentional.
## What NOT to Do
No premature UI or infographic elements, no dense paragraphs, no generic card slides, no unrelated celebrity portraits, no source/footer labels, no fabricated actual product screenshots or quotes. Checkout and message flow are explanatory mockups, not an actual transaction.
