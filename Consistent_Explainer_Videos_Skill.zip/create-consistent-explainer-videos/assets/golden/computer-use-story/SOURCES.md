Primary source: Anthropic, Developing a computer use model (22 October 2024). https://www.anthropic.com/news/developing-computer-use
Claims: screenshot interpretation; mouse and keyboard action; checking state and self-correction; variable reliability. The CRM workflow, names and business are illustrative. No actual product execution or performance guarantee is depicted.
