---
name: create-consistent-explainer-videos
description: Create polished 60-second silent portrait explainer videos from a topic, infographic or article in Anurag's approved editorial style. Use for new topics, next-topic requests, or consistent repeats of the computer-use, payment-journey and agentic-commerce videos. Preserve the bundled fonts, colours, headers, centred leads, readable pacing, native animated UI examples and footer-free design. Includes portable code and exact approved reference projects.
---
# Consistent Explainer Videos

Use the bundled design and renderer, not a new interpretation of the style. Work autonomously from a topic or infographic; do not ask for style, colour, music or aspect-ratio choices already fixed here.

## Lock the output
- Deliver one real MP4: **1080 × 1350, 30 fps, 60.000 seconds, no audio**.
- Preserve paper `#F4F1E8`, ink `#183535`, yellow `#F3D55B`, blue `#DCEEF0`, green `#CBE6D8`.
- Use the embedded FilmSerif/P052 and FilmSans/Nimbus fonts, not replacements or web fonts.
- Keep the compact dark uppercase header distinct from the centred serif scene lead. Open with a large title and yellow phrase, then reveal the header at 7.7 seconds.
- Keep the original panel borders, rounded corners, restrained shadows, spacing, crossfades, progress line and slow reading holds.
- Do not add footer labels, watermarks, voice, music, subtitles, unrelated faces, invented endorsements, decorative neon or a different template.
- Consider a relevant face only if it explains the story and is grounded in a real source. Do not force a celebrity into a process explanation.

## Load the reference
Read [style-and-story.md](references/style-and-story.md), [brief-format.md](references/brief-format.md), and [portability.md](references/portability.md). Look at `references/approved-contact-sheet.jpg` when present and the actual approved MP4s under `assets/golden/`.
The original **computer-use-story** is the user's explicit style approval. **payment-journey** and **agentic-commerce** are proven topic adaptations. Their original HTML, media and approved MP4s are bundled for exact replay. Never overwrite them.

## Produce the video
1. Extract the topic's main idea and constraints. Verify niche/current/high-stakes claims against primary sources if browsing is available. Record sources and distinguish hypothetical examples from measured results. Never invent numerical evidence or imply all retailers/tools support a capability.
2. Choose **one concrete example**, then develop a **story → mechanism/framework → takeaway**. Explain how something works instead of listing definitions. Keep sentences flowing, direct and easy to read. Use 3–4 explanatory beats.
3. Write a content-only `brief.json` using the format below. Use exactly six scenes at 0, 8, 18, 28, 39 and 49 seconds. Prefer 140–190 narrative words; UI labels can add words, but simplify scenes over 60 visible words. Every scene must have one clear purpose.
4. Build using the bundled script, resolving `<skill>` to this directory:
   ```bash
   python3 <skill>/scripts/build.py brief.json output-project
   python3 <skill>/scripts/render.py output-project --output final.mp4
   ```
   Use a new output directory for each run. The script copies locked assets and constructs seekable animations. Do not rewrite CSS or the renderer to fit verbose content. Shorten copy or choose a supported panel instead.
5. Inspect all hero frames and transitions. Read `quality-check.log`, `snapshots.log`, and `verification.json`. A successful command alone is not visual approval. Fix copy/content and rebuild into a fresh output directory if needed. Follow [quality-gates.md](references/quality-gates.md).
6. Deliver the verified MP4 with a working file link. Preserve the editable project/brief according to the host's file-saving workflow. Keep the response short. Do not imply that a script or HTML file is the finished video.

## Consistency self-test
Run `python3 <skill>/scripts/test_consistency.py` before first use. It checks asset integrity, identical same-brief builds and rejection of overlong content. Use the bundled example brief unchanged and compare with `assets/example-output.mp4` for cross-platform comparison. See [validation.md](references/validation.md) for what was actually tested.

## Exact replay versus new topics
For exact reproduction of an approved video, copy its bundled `approved.mp4`; that preserves its exact bytes. To edit an approved topic with minimal differences, copy that golden project and change only its content, then run `scripts/render.py` against the copy. For new topics, use the constrained JSON builder.

Same JSON + unchanged assets/code produces identical HTML and animation instructions. Exact encoded MP4 bytes/pixels across different OS, Chrome or FFmpeg versions are not guaranteed. Keep runtime versions fixed for closest reproduction; never claim this package was tested on every AI platform. A chat-only model cannot render MP4s without an execution environment.
