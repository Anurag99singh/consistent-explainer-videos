#!/usr/bin/env python3
"""Check deterministic builds and rejection of overlong copy without rendering."""
import copy,hashlib,json,tempfile
from pathlib import Path
from build import ROOT,build,verify
verify();d=json.loads((ROOT/'assets/example-brief.json').read_text())
with tempfile.TemporaryDirectory() as td:
 a,b=Path(td)/'a',Path(td)/'b';build(d,a);build(d,b)
 def manifest(p):return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
 assert manifest(a)==manifest(b),'Same brief generated different artifacts'
 bad=copy.deepcopy(d);bad['scenes'][0]['lead']='x'*100
 try:build(bad,Path(td)/'bad')
 except ValueError:pass
 else:raise AssertionError('Overlong title was accepted')
print('PASS: locked asset integrity; identical same-brief builds; overlong-copy rejection')
