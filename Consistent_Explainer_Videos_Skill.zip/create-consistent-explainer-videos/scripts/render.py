#!/usr/bin/env python3
"""Pinned HyperFrames -> lossless frames -> bounded-thread FFmpeg -> verified silent MP4."""
import argparse,json,shutil,subprocess,sys,os
from pathlib import Path

def run(argv,cwd,log):
 with log.open('w') as f:
  r=subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'HYPERFRAMES_NO_TELEMETRY':'1','DO_NOT_TRACK':'1'})
 if r.returncode:raise RuntimeError(f'Command failed; inspect {log}')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('project',type=Path);a.add_argument('--output',type=Path);a.add_argument('--check-only',action='store_true');args=a.parse_args()
 p=args.project.resolve();out=(args.output or p/'final.mp4').resolve()
 for tool in ['node','npx','ffmpeg','ffprobe']:
  if not shutil.which(tool):sys.exit('Missing '+tool+'. See references/portability.md')
 cli=['npx','--yes','hyperframes@0.8.216']
 run(cli+['check'],p,p/'quality-check.log')
 text=(p/'quality-check.log').read_text()
 layout=text.split('Layout',1)[-1].split('Motion',1)[0]
 if '⚠' in layout or any(code in layout for code in ['container_overflow','canvas_overflow','panel_out_of_canvas','content_overlap']):raise RuntimeError('Unresolved layout issue; simplify the brief and rebuild. See quality-check.log')
 run(cli+['snapshot','--at','0,3,12,22,36,46,58'],p,p/'snapshots.log')
 if not args.check_only:
  frames=p/'rendered-frames'
  if frames.exists():sys.exit('rendered-frames already exists; choose a fresh project/output directory')
  run(cli+['render','--format','png-sequence','--output',str(frames),'--fps','30','--quality','high','--workers','2'],p,p/'render.log')
  out.parent.mkdir(parents=True,exist_ok=True)
  run(['ffmpeg','-y','-hide_banner','-loglevel','error','-framerate','30','-start_number','1','-i',str(frames/'frame_%06d.png'),'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads','2','-an','-movflags','+faststart',str(out)],p,p/'encode.log')
  info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out)]))
  v=[s for s in info['streams'] if s['codec_type']=='video'];assert len(v)==1 and not any(s['codec_type']=='audio' for s in info['streams'])
  assert v[0]['width']==1080 and v[0]['height']==1350 and v[0]['r_frame_rate']=='30/1' and int(v[0]['nb_frames'])==1800
  assert abs(float(info['format']['duration'])-60)<.01
  (p/'verification.json').write_text(json.dumps(info,indent=2));print(out)
 else:print('Checks and snapshots complete. Inspect snapshots before delivery.')
