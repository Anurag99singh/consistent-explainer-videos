#!/usr/bin/env python3
"""Build the locked approved design from a content-only JSON brief. Python 3.10+."""
import argparse,hashlib,html,json,re,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def verify():
 for name,digest in json.loads((ROOT/'assets/LOCK.json').read_text()).items():
  if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise ValueError('Locked asset changed: '+name)
def esc(s,limit=100):
 if not isinstance(s,str) or not s.strip() or len(s)>limit:raise ValueError(f'Expected nonempty text <= {limit} characters: {s!r}')
 return html.escape(s,quote=True)
def panel(p,project,idx):
 kind=p['type']; title=esc(p.get('title','ILLUSTRATIVE WORKFLOW'),48)
 chrome='<div class="chrome"><span class="dots">● ● ●</span><span>'+esc(p.get('chrome','EXAMPLE / WORKFLOW'),44)+'</span><span>•••</span></div>'
 t='<p class="paneltitle">'+title+'</p>'
 if kind=='rows':
  rows=p['rows'];assert 1<=len(rows)<=4
  body=t+''.join('<div class="specrow"><span>'+esc(a,30)+'</span><b>'+esc(b,36)+'</b></div>' for a,b in rows)
 elif kind=='workflow':
  rows=p['rows'];assert 1<=len(rows)<=3
  body=t+''.join('<div class="workflowrow"><span>'+esc(a,30)+'</span><b>'+esc(b,30)+'</b></div>' for a,b in rows)
  body+='<div class="action" data-layout-allow-occlusion><span data-layout-allow-occlusion>'+esc(p['action'],42)+'</span><span class="success-label">'+esc(p['success'],42)+'</span></div>'
  if p.get('note'):body+='<p class="smallnote">'+esc(p['note'],65)+'</p>'
 elif kind=='chat':
  body='<p class="mini">'+title+'</p><p class="chatquestion">'+esc(p['question'],65)+'</p><p class="chatanswer">'+esc(p['answer'],75)+'</p><div class="chatlearned"><b>'+esc(p['learned_label'],35)+'</b>'+esc(p['learned'],70)+'</div>'
 elif kind=='diagram':
  assert len(p['nodes'])==3
  body=t+'<div class="nodes">'+ '<span class="routearrow">→</span>'.join('<div class="nodebox">'+esc(n,36)+'</div>' for n in p['nodes'])+'</div><p class="diagramcaption">'+esc(p['caption'],85)+'</p>'
 elif kind=='product':
  image=''
  if p.get('image'):
   src=Path(p['image']).expanduser().resolve();assert src.suffix.lower() in ['.png','.jpg','.jpeg','.webp','.svg']
   name='topic-'+str(idx)+src.suffix.lower();shutil.copyfile(src,project/'assets'/name)
   image='<img class="productimage" src="assets/'+name+'" alt="">'
  body='<div class="productrow">'+image+'<div class="productcopy"><h3>'+title+'</h3><p>'+esc(p['description'],65)+'</p></div></div><div class="intent">'+esc(p['request'],85)+'</div><div class="productstatus">'+esc(p['status'],65)+'</div>'
 else:raise ValueError('Unsupported panel: '+kind)
 if kind=='workflow':body+='<svg class="cursor" viewBox="0 0 70 86" data-layout-ignore><path d="M7 5 L7 67 L23 52 L37 79 L51 72 L37 46 L61 44 Z" fill="#F3D55B" stroke="#183535" stroke-width="5" stroke-linejoin="round"/></svg>'
 return '<div class="browser panel'+kind+'">'+chrome+'<div class="panelbody">'+body+'</div></div>'
def build(d,out):
 verify();assert len(d['scenes'])==6
 out.mkdir(parents=True,exist_ok=True);(out/'assets').mkdir(exist_ok=True)
 for n in ['style.css','gsap.min.js','sans.otf','sans-bold.otf','serif.otf']:shutil.copyfile(ROOT/'assets'/n,out/'assets'/n)
 parts=[]
 for i,s in enumerate(d['scenes']):
  lead=esc(s['lead'],48 if i==0 else 64)
  if i==0 and s.get('emphasis'):
   emphasis=esc(s['emphasis'],25);assert emphasis in lead;lead=lead.replace(emphasis,'<em>'+emphasis+'</em>',1)
  inner='<p class="kicker">'+esc(s['kicker'],40)+'</p><'+('h1' if i==0 else 'h2')+' class="lead">'+lead+'</'+('h1' if i==0 else 'h2')+'><p class="deck">'+esc(s['deck'],95)+'</p>'
  if i==5:
   assert 3<=len(s['items'])<=4
   inner+='<div class="loop">'+''.join('<div class="loopitem"><span class="loopnum">'+f'{j+1:02}'+'</span><div><h3>'+esc(a,44)+'</h3><p>'+esc(b,65)+'</p></div></div>' for j,(a,b) in enumerate(s['items']))+'</div><p class="payoff">'+esc(s['payoff'],90)+'</p>'
   if s.get('scope'):inner+='<p class="limit">'+esc(s['scope'],85)+'</p>'
  else:
   inner+=panel(s['panel'],out,i)
   if s.get('callout'):inner+='<div class="callout">'+esc(s['callout'],95)+'</div>'
   elif s.get('note'):inner+='<p class="'+('hookline' if i==0 else 'note')+'">'+esc(s['note'],85)+'</p>'
  words=len(re.sub('<[^>]+>',' ',inner).split())
  if words>66:raise ValueError(f'Scene {i} has {words} words; simplify to <=66 including UI labels')
  parts.append('<div id="s'+str(i)+'" class="scene'+(' intro' if i==0 else ' closing' if i==5 else '')+'">'+('' if i==0 else '<div class="rule"></div>')+'<div class="content" data-hold data-layout-allow-overlap>'+inner+'</div></div>')
 js="""const tl=gsap.timeline({paused:true});window.__timelines={main:tl};const starts=[0,8,18,28,39,49];
 starts.forEach((t,i)=>{const s='#s'+i;if(i){tl.to('#s'+(i-1),{opacity:0,duration:.5,ease:'power2.inOut'},t);tl.to(s,{opacity:1,duration:.5,ease:'power2.inOut'},t);}Array.from(document.querySelector(s+' .content').children).forEach((e,j)=>{if(e.classList.contains('payoff')||e.classList.contains('limit'))return;tl.from(e,{opacity:i===0&&e.classList.contains('lead')?1:0,y:j%2?28:15,duration:.65,ease:['power3.out','sine.out','expo.out'][j%3],immediateRender:true},t+.15+j*.2)});
 const rows=document.querySelectorAll(s+' .specrow, '+s+' .workflowrow, '+s+' .nodebox');if(rows.length)tl.from(rows,{opacity:0,x:-14,duration:.5,stagger:.35,ease:'power3.out'},t+1.5);
 if(document.querySelector(s+' .action')){const box=document.querySelector(s+' .browser').getBoundingClientRect(),b=document.querySelector(s+' .action').getBoundingClientRect();const x=b.right-box.left-60,y=b.top-box.top+b.height/2-12;tl.fromTo(s+' .cursor',{x:x-130,y:y-120},{x,y,duration:1.1,ease:'power2.inOut',immediateRender:true},t+4.5);tl.to(s+' .success-label',{opacity:1,duration:.4,ease:'sine.out'},t+6.7)}
 if(document.querySelector(s+' .chatquestion')){tl.from(s+' .chatquestion',{opacity:0,y:16,duration:.6,ease:'power3.out'},t+1.3);tl.from(s+' .chatanswer',{opacity:0,x:20,duration:.5,ease:'sine.out'},t+3.1);tl.from(s+' .chatlearned',{opacity:0,y:16,duration:.6,ease:'expo.out'},t+5.1)}
 });tl.to('.banner',{opacity:1,duration:.5,ease:'sine.out'},7.7);tl.from('.banner',{y:24,duration:.6,ease:'expo.out'},7.7);tl.from('.progress',{scaleX:0,duration:60,ease:'none'},0);tl.from('#s5 .loopitem',{opacity:0,x:-18,duration:.6,stagger:.5,ease:'power3.out'},50.1);tl.from('.payoff',{opacity:0,y:24,duration:.7,ease:'sine.out'},55);if(document.querySelector('.limit'))tl.from('.limit',{opacity:0,y:15,duration:.6,ease:'power2.out'},57.2);"""
 h='<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080,height=1350"><style>'+(ROOT/'assets/style.css').read_text()+'</style><script src="assets/gsap.min.js"></script></head><body><div id="root" data-composition-id="main" data-width="1080" data-height="1350" data-start="0" data-duration="60">'+''.join(parts)+'<div class="banner"><b>'+esc(d['header'],36)+'</b><span>'+esc(d['tag'],22)+'</span></div><div class="progress" data-layout-ignore></div></div><script>'+js+'</script></body></html>'
 (out/'index.html').write_text(h);(out/'brief.json').write_text(json.dumps(d,indent=2,ensure_ascii=False))
 (out/'package.json').write_text(json.dumps({'private':True}))
 (out/'sources.md').write_text(d.get('sources','Illustrative workflow. Verify topic facts before publication.'))
 print(out/'index.html')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('brief',type=Path);a.add_argument('output',type=Path);args=a.parse_args();build(json.loads(args.brief.read_text()),args.output.resolve())
