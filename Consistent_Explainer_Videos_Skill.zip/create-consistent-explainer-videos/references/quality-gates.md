# Quality gates

1. Confirm the source claim and any caveats. No invented quotes, benchmark numbers, real prices/ratings or endorsement. Keep sources outside the video unless the user requests visible attribution. Distinguish analogy from literal mechanism.
2. Inspect the intro, four middle hero frames, final frame, and scene transitions. Check no future scene leaks through at t=0. Check all important text has at least 3–6 seconds after entrance; simplify if reading feels rushed.
3. Resolve text/container/canvas overflow, missing assets, occlusion, unintended overlap and poor contrast. Crossfade overlap and the success overlay are intentional; never hide genuine layout problems with ignore flags. Long copy must be shortened, not squeezed into tiny type.
4. Read `quality-check.log`: require zero runtime/lint errors, no unresolved layout warnings, passing text contrast. Silent-film warnings are intentional. Auxiliary UI labels can be below 28px only when they match the approved reference; never shrink primary reading text.
5. Confirm correct cursor placement, ordered row/chat reveals, readable success state, and visible closing question. Do not double-apply opacity entrances.
6. Require verified output: one video stream, 1080x1350, 30 fps, 1800 frames, 60 seconds, zero audio streams, MP4/H.264 yuv420p. The render script enforces these technical gates but does not replace visual review.
7. Check actual encoded MP4 frames, not only HTML screenshots. Include a working download link. Preserve the editable project and brief. Do not claim universal cross-platform validation or exact byte equality for newly generated content.

If no supported panel can explain the topic, clone the closest golden project and change only content first. A genuinely new component requires matching locked tokens, explicit visual inspection and comparison with the approved reference; do not silently redesign the film.
