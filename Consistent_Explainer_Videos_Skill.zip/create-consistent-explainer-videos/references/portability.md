# Portability and execution

## On another AI platform
Unzip the entire package. Ask the AI to read SKILL.md and its references, create a content-only JSON brief for the new topic, and run the bundled build/render scripts. If the platform supports skills, install the whole folder through its supported mechanism; if not, attach the ZIP and ask it to follow SKILL.md. Do not upload only SKILL.md: the fonts, approved references, CSS, code and local animation library are essential.

Requirements: Python >=3.10, Node.js >=22, npm/npx, FFmpeg/ffprobe with libx264, sufficient disk space (~0.5–1 GB per render), and a headless Chrome supported by HyperFrames. Initial npm/browser setup may need network access. No OpenAI API key, paid video API, personal connector, Google Drive, or ChatGPT-specific tool is required to render.

The wrapper disables HyperFrames telemetry for each subprocess via the documented HYPERFRAMES_NO_TELEMETRY=1 and DO_NOT_TRACK=1 opt-outs. Preserve these settings if running CLI commands manually.

The renderer pins `hyperframes@0.8.216`. It uses PNG-sequence export and a separate FFmpeg encode with two threads, avoiding the MP4 assembly failure observed in the original workflow. Keep Python, Chrome, OS, fonts and FFmpeg versions constant for closer pixel-level reproducibility. The GSAP and font bytes are included. Asset checksums prevent accidental design drift.

If dependencies are missing, use the official installation methods for that OS. If execution/network is unavailable, produce the brief and explain the exact missing capability. Do not pretend a video was rendered. Transfer the folder and brief to a capable coding environment and run the two commands in SKILL.md there.

A prompt alone cannot force every model to choose identical wording or a chat-only platform to encode video. The renderer fixes the visual system; the example brief fixes content for repeatability testing. New topics change the content. User-approved golden MP4s provide exact reference outputs without re-encoding.

## First consistency test
Run the supplied example brief unchanged and compare with assets/example-output.mp4. Then run it again in a second fresh output directory. Compare the generated HTML and static assets (should be byte-identical), and inspect the same timestamps visually. Compare MP4 bytes only when the full render environment is also fixed; identical HTML is not proof of equivalent storytelling on a new topic.

Try: “Read this skill and make a video about why AI agents need memory. Preserve the locked design, use one concrete example, run the checks, inspect the frames, and give me the verified MP4.”
