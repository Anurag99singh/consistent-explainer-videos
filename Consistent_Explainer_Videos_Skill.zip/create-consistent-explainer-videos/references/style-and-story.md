# Approved style and story contract

The user's explicit feedback was that the computer-use video was the best and exactly what was wanted. Lock that visual language for subsequent topics.

## Story
Start with a question someone can understand without knowing the jargon. Carry one named task or example through the middle scenes. Make each mechanism concrete with an animated app/form, fields, state change, conversation or diagram. End with a compact framework and useful insight/question. Use hypothetical names, prices and data only as clearly illustrative examples.

Do not crop a whole infographic into a slide deck or substitute slow zooms for explanation. An uploaded infographic supplies the argument and optional illustration; recreate the mechanism using the approved native UI. Do not copy source logos, author photos or branding as an implied endorsement.

## Composition
Main: padding 177px 64px 75px, vertical gap 29px. Intro: top padding 106px, gap 28px. Header: left/right 55px, top 45px, height 67px, 12px radius. Main lead: FilmSerif 76px/1.04, tracking -2.8px, centred. Intro: 99px, yellow highlighted phrase. Body: FilmSans 33px/1.3. Panel: 952px wide, radius 25px, 2px #b8c8c0 border, #fffef9 surface, 16px restrained shadow. Closing framework uses three or four rows with serif numbers, bold short headings, one explanatory sentence each.

## Animation
Synchronous paused GSAP timeline registered as `window.__timelines.main`. Six scenes with container-level .5s crossfades. Hide all future scenes initially. Animate content in with .65s entrances, 15/28px offset, .2s stagger, varying power3/sine/expo ease. Use long holds for reading, not constant motion. A cursor must land on the intended control, not obscure its label. Use the builder's DOM-based target calculation. Overlay success states explicitly; keep future chat responses concealed until their cue. Do not double-animate opacity on the same element; this previously left closing lines invisible.

## Adaptation boundaries
Change topic, copy, example data, supplied illustration, panel types and framework labels. Do not change palette, fonts, dimensions, silence, visual hierarchy or general timing. If the content does not fit, simplify it. Request user input only for a materially missing fact, not to repeat approved preferences.
