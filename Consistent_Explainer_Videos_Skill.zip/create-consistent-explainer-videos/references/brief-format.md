# Content-only brief
Use `assets/example-brief.json` as an executable example. All text is escaped by the builder; raw HTML/JS/CSS is not accepted.

Top level: `header` (<=36 characters), `tag` (<=22), `sources` (plain text with source URLs and factual/illustrative scope), `scenes` (exactly six objects).

Every scene: `kicker` <=40, `lead` <=64 (intro <=48), `deck` <=95 characters. Scene 0 can specify `emphasis` (an exact substring of the lead, <=25). For scenes 0–4, supply `panel` and optionally either `callout` <=95 or `note` <=85. Omit optional text rather than fill space.

Panel fields common to all: `type`, `title` <=48, `chrome` <=44. Types:

| type | Required content | Use |
|---|---|---|
| rows | `rows`: 1–4 [label <=30, value <=36] pairs | Facts, constraints, profiles |
| workflow | `rows`: 1–3 [label <=30, status <=30] pairs; `action` <=42; `success` <=42; optional `note` <=65 | Click, approval, save, checkout; cursor and success overlay included |
| chat | `question` <=65; `answer` <=75; `learned_label` <=35; `learned` <=70 | Feedback and correction, staggered reveals included |
| diagram | `nodes`: exactly three strings <=36; `caption` <=85 | Causal chain, handoffs, roles |
| product | `description` <=65; `request` <=85; `status` <=65; optional `image`: readable local PNG/JPEG/WebP/SVG path | Opening example; optional supplied illustration |

Scene 5 has no panel. Supply `items`: 3–4 [heading <=44, sentence <=65] pairs; `payoff` <=90; optional `scope` <=85. Use the same numbering in the middle and summary. Prefer short leads: character limits alone do not ensure fit. Review actual rendered wrapping.

Use `workflow` only to depict the example, not to execute a real purchase/message/account change. Approval in a mockup is fictional. For consequential real actions, obey the host platform's authorization requirements.
